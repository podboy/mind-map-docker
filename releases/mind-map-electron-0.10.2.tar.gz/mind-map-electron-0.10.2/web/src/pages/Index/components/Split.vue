<template>
  <div class="splitContainer"></div>
</template>

<script>
export default {}
</script>

<style lang="less" scoped>
.splitContainer {
  width: 122px;
  height: 15px;
  background-image: url('../../../assets/img/index/split.png');
  background-size: cover;
}
</style>
