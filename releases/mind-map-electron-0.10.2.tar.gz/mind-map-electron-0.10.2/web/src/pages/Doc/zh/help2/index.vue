<template>
  <div>
    <h1>客户端</h1>
<h2>安装</h2>
<p>目前提供了两个客户端下载方式：</p>
<p>1.百度云：<a href="https://pan.baidu.com/s/1huasEbKsGNH2Af68dvWiOg?pwd=3bp3">https://pan.baidu.com/s/1huasEbKsGNH2Af68dvWiOg?pwd=3bp3</a></p>
<p>2.Github：<a href="https://github.com/wanglin2/mind-map/releases">https://github.com/wanglin2/mind-map/releases</a></p>
<p>Windows用户请下载<code>Setup.[版本].exe</code>或<code>[版本].exe</code>文件。</p>
<p>Mac用户请下载<code>.dmg</code>文件。</p>
<p>Linux用户请下载<code>.AppImage</code>文件。</p>
<p>如果Mac安装出现<code>已损坏</code>问题，可以参考这篇文章：<a href="https://www.jianshu.com/p/031efc52ccea">苹果M1芯片安装xxx.app 显示已损坏，无法打开，你应该将它移到废纸篓/打不开 xxx，因为它来自身份不明的开发者 如何解决？</a>。</p>
<h2>使用</h2>
<p>客户端名称为<code>思绪</code>，对应的思维导图文件后缀名为<code>.smm</code>。</p>
<p>客户端相比在线版，多了一个显示最近文件列表的页面，你打开过的文件都会显示在最近列表里。</p>
<p>除了点击打开文件按钮打开文件外，你也可以直接将文件拖入到列表页面，如果拖入一个文件，那么会直接打开进行编辑，如果同时拖入了多个文件，那么会直接添加到列表里，不会打开编辑。</p>

  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>