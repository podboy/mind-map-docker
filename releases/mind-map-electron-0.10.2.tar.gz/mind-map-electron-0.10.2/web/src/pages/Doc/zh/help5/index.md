# 导出

## 导出为xmind

导出的xmind文件无法在xmind8及以下版本打开，请使用最新版xmind软件。