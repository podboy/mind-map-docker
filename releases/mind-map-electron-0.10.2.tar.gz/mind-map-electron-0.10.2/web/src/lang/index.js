import en from './en_us'
import zh from './zh_cn'

export default {
  zh,
  en
}
