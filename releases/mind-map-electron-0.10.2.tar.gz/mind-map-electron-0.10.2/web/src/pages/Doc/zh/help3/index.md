# 打开预览在线文件

v0.7.0+版本支持打开url中携带的在线文件：

```
https://wanglin2.github.io/mind-map/#/?fileURL=http://xxx.com/xxx.xmind
```

在`fileURL`参数后带上你的在线文件url即可，目前支持`.xmind`、`.smm`、`.json`、`.md`后缀的文件url。

需要注意的是你在打开在线文件的情况下编辑并不会修改在线文件，改动会保存在你的浏览器本地，你可以选择导出文件。