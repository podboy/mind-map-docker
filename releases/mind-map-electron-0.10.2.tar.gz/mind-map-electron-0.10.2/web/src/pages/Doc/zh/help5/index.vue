<template>
  <div>
    <h1>导出</h1>
<h2>导出为xmind</h2>
<p>导出的xmind文件无法在xmind8及以下版本打开，请使用最新版xmind软件。</p>

  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>